package com.example.employee;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    @GetMapping("/")
    public String data() {
        Employee e = new Employee(122,"abc","kormanagala",560062);
        return "employee id: "+e.getId()+"employee name: "+e.getName()+"employee address: "+e.getAddress()+"employee zipcode: "+e.getZipcode();
    }


    
}
