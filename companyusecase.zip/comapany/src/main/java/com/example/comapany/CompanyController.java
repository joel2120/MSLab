package com.example.comapany;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/companies")
public class CompanyController {
    @GetMapping("/")
    public String data() {
        Company c = new Company(1,"joel","mspalaya",560097);
        return "company id: "+c.getId()+"company name: "+c.getName()+"comapny address: "+c.getAddress()+"comapny zipcode: "+c.getZipcode();
    }


    
}
