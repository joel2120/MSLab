package com.example.comapany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComapanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
